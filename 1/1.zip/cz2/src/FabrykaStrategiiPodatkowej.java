public interface FabrykaStrategiiPodatkowej {

    public StrategiaPodatkowa stworzStrategiePodatkowa();
}
