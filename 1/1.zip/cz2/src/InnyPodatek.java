public class InnyPodatek implements Podatek{

    @Override
    public double okreslWartoscPodatku(double sum) {
        return 0;
    }
}
