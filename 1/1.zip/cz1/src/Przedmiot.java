abstract public class Przedmiot {
    public abstract double okreslWartosc();
}
