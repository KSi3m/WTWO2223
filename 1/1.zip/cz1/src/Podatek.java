public interface Podatek {
    public double okreslWartoscPodatku(double sum);

}
